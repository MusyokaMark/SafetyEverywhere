package com.example.safety;

public class FusedLocationProviderClient {
}
